global runtime = 0
