    T1
    M109 S260
    M118 P0 S"Loading CFF"
    M83
    G1 E10 F100
    G1 E70 F200
    G1 E50 F100
    M400
