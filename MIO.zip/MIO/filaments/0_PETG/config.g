M572 D0 S0.060							        ;Pressure Adv PLA settings
M591 D0 S1 L32 A0 E10                          ;Filament Monitor settings
